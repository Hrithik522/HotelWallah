var hotels = ["Erumdadam- The Treehouse","Le Tranquil","Quinta Da Santana Luxury Villa",
"Paddle HouseBoats 1","Sunny Side Cottage with lake view"];
let ad = document.getElementById("inpadult");
let chil = document.getElementById("inpchild");